﻿Partial Class andrewDataset
    Partial Public Class _dbo_UserDataTable

    End Class
End Class

Namespace andrewDatasetTableAdapters
    Partial Public Class UserTableAdapter
    End Class

    Partial Public Class dbo_UserTableAdapter
    End Class
End Namespace

Namespace andrewDatasetTableAdapters
    Partial Public Class UserTableAdapter
    End Class
End Namespace
